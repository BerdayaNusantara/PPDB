#
# TABLE STRUCTURE FOR: alasan
#

DROP TABLE IF EXISTS `alasan`;

CREATE TABLE `alasan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `alasan` (`id`, `judul`, `deskripsi`) VALUES (1, 'Alasan A', 'Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi');
INSERT INTO `alasan` (`id`, `judul`, `deskripsi`) VALUES (2, 'Alasan B', 'Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi');
INSERT INTO `alasan` (`id`, `judul`, `deskripsi`) VALUES (3, 'Alasan C', 'Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi');
INSERT INTO `alasan` (`id`, `judul`, `deskripsi`) VALUES (4, 'Alasan D', 'Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi');


#
# TABLE STRUCTURE FOR: alur_pendaftaran
#

DROP TABLE IF EXISTS `alur_pendaftaran`;

CREATE TABLE `alur_pendaftaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `keterangan` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `alur_pendaftaran` (`id`, `nama`, `tanggal`, `keterangan`) VALUES (2, 'Akses situs', '2021-02-01', 'Calon santri dan wali santri wajib membaca semua hal yang berkaitan dengan Pendaftaran Santri Baru (PSB) Pesantren Modern Al-Manar, mulai dari Syarat Pendaftaran, Syarat Administrasi, Jadwal Pendaftaran dan Tata Cara Pandaftaran dengan mengakses hala');
INSERT INTO `alur_pendaftaran` (`id`, `nama`, `tanggal`, `keterangan`) VALUES (3, 'Tunggu Konfirmasi dari Panitia', '2021-03-01', 'Tunggu hingga mendapatkan notifikasi pesan dari Panitia ');
INSERT INTO `alur_pendaftaran` (`id`, `nama`, `tanggal`, `keterangan`) VALUES (4, 'Login ke situs pendaftaran', '2021-03-01', 'Selanjutnya, akses halaman situs almanar.ponpes.id/psb/login-user dengan LOGIN menggunakan NISN dan Tanggal Lahir untuk melakukan pengisian data berupa:\r\n\r\n- Data diri\r\n\r\n- Data Orang Tua\r\n\r\n- Data Wali\r\n\r\n- Data Dokumen.\r\n\r\nNB: Jangan lupa menekan t');


#
# TABLE STRUCTURE FOR: app_information
#

DROP TABLE IF EXISTS `app_information`;

CREATE TABLE `app_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(250) NOT NULL,
  `instansi` varchar(250) NOT NULL,
  `tahun` int(11) NOT NULL,
  `logo` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `app_information` (`id`, `nama`, `instansi`, `tahun`, `logo`) VALUES (1, 'PPDB Online', 'SMK Muhammadiyah 2 Cepu', 2020, 'logo.png');


#
# TABLE STRUCTURE FOR: biaya
#

DROP TABLE IF EXISTS `biaya`;

CREATE TABLE `biaya` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `biaya` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `biaya` (`id`, `biaya`) VALUES (1, 10000);


#
# TABLE STRUCTURE FOR: biaya_pendidikan
#

DROP TABLE IF EXISTS `biaya_pendidikan`;

CREATE TABLE `biaya_pendidikan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `biaya` int(11) NOT NULL,
  `keterangan` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `biaya_pendidikan` (`id`, `biaya`, `keterangan`) VALUES (2, 150000, 'Biaya Pendaftaran');
INSERT INTO `biaya_pendidikan` (`id`, `biaya`, `keterangan`) VALUES (3, 1500000, 'Uang Gedung');


#
# TABLE STRUCTURE FOR: jadwal
#

DROP TABLE IF EXISTS `jadwal`;

CREATE TABLE `jadwal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jenjang` varchar(100) NOT NULL,
  `nama_tes` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `kuota` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=latin1;

INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (27, 'SDIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-13', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (28, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-03', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (29, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-04', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (30, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-05', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (31, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-06', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (32, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-03', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (33, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-04', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (34, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-05', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (35, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-06', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (36, 'TKIT', '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', '2021-02-07', 'Offline', 2);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (37, 'TKIT', '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', '2021-02-13', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (40, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-11', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (41, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-12', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (42, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-11', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (43, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-12', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (44, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-13', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (45, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-13', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (47, 'SMPIT Quran', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-27', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (48, 'TKIT A', '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', '2021-02-27', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (49, 'TKIT B', '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', '2021-02-27', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (50, 'SDIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-27', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (51, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-18', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (52, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-19', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (53, 'SMAIT', '-test akademik <br> -test baca iqro<br>test psikologi<br> -wawancara', '2021-03-01', 'Online', 1);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (54, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-24', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (55, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-25', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (56, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-26', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (57, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-26', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (58, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-03', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (59, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-04', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (60, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-05', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (61, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-06', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (62, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-03', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (63, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-04', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (64, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-05', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (65, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-06', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (66, 'SMPIT Quran', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-06', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (67, 'TKIT A', 'TES AWAL', '2021-03-11', 'Online', 90);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (68, 'TKIT B', 'TES AWAL', '2021-03-11', 'Online', 90);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (69, '5', 'TES AWAL', '2021-03-31', 'Offline', 100);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (70, '4', 'Tes Kecakapan', '2021-03-31', 'Offline', 100);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (71, '7', 'TES FISIK', '2021-04-15', 'Offline', 35);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (72, '6', 'Tes Kecakapan', '2021-04-30', 'Offline', 100);


#
# TABLE STRUCTURE FOR: jadwal_pendaftaran
#

DROP TABLE IF EXISTS `jadwal_pendaftaran`;

CREATE TABLE `jadwal_pendaftaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal_mulai` date DEFAULT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `nama` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `jadwal_pendaftaran` (`id`, `tanggal_mulai`, `tanggal_selesai`, `nama`) VALUES (2, '2021-02-01', '2021-04-30', 'Pendaftaran Online');


#
# TABLE STRUCTURE FOR: jadwal_ujian
#

DROP TABLE IF EXISTS `jadwal_ujian`;

CREATE TABLE `jadwal_ujian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idunik` text NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jenjang
#

DROP TABLE IF EXISTS `jenjang`;

CREATE TABLE `jenjang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `keterangan` varchar(250) DEFAULT NULL,
  `logo` text DEFAULT NULL,
  `kuota` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `jenjang` (`id`, `nama`, `keterangan`, `logo`, `kuota`) VALUES (4, 'Teknik Kendaraan Ringan (Otomotif)', 'Mitra Industri TOYOTA Kudus (CV. Surya Indah Motor)', 'logo_Teknik_Kendaraan_Ringan_(Otomotif)_20210320105447.png', 100);
INSERT INTO `jenjang` (`id`, `nama`, `keterangan`, `logo`, `kuota`) VALUES (5, 'Teknik Instalasi Tenaga Listrik', 'Mitra Industri PT. B&D Transformer', 'logo_Teknik_Instalasi_Tenaga_Listrik_20210320105536.png', 1);
INSERT INTO `jenjang` (`id`, `nama`, `keterangan`, `logo`, `kuota`) VALUES (6, 'Teknik Bisnis & Sepeda Motor', 'Mitra Industri PT. Astra Honda Motor', 'logo_20210320105818.png', 100);
INSERT INTO `jenjang` (`id`, `nama`, `keterangan`, `logo`, `kuota`) VALUES (7, 'Asisten Keperawatan', 'Mitra RS PKU Muhammadiyah', 'logo_20210320105859.png', 100);


#
# TABLE STRUCTURE FOR: kelas
#

DROP TABLE IF EXISTS `kelas`;

CREATE TABLE `kelas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `jenjang_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `kelas_jenjang_id_IDX` (`jenjang_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `kelas` (`id`, `nama`, `jenjang_id`) VALUES (2, 'X A', 4);
INSERT INTO `kelas` (`id`, `nama`, `jenjang_id`) VALUES (3, 'X B', 4);
INSERT INTO `kelas` (`id`, `nama`, `jenjang_id`) VALUES (4, 'X C', 4);
INSERT INTO `kelas` (`id`, `nama`, `jenjang_id`) VALUES (5, 'X A', 5);
INSERT INTO `kelas` (`id`, `nama`, `jenjang_id`) VALUES (6, 'X A', 6);


#
# TABLE STRUCTURE FOR: keringanan_biaya
#

DROP TABLE IF EXISTS `keringanan_biaya`;

CREATE TABLE `keringanan_biaya` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keterangan` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `keringanan_biaya` (`id`, `keterangan`) VALUES (2, 'Siswa berprestasi akademik peringkat 1.');
INSERT INTO `keringanan_biaya` (`id`, `keterangan`) VALUES (3, 'Siswa berprestasi non-akademik ( Juara tingkat kabupaten dna procinsi ).');
INSERT INTO `keringanan_biaya` (`id`, `keterangan`) VALUES (4, 'Siswa yang orang tuanya bekerja di Muhammadiyah.');


#
# TABLE STRUCTURE FOR: konfigurasi_sistem
#

DROP TABLE IF EXISTS `konfigurasi_sistem`;

CREATE TABLE `konfigurasi_sistem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_server` text DEFAULT NULL,
  `api_whatsapp` text NOT NULL,
  `api_ipaymu` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `email_subject` varchar(100) DEFAULT NULL,
  `email_host` varchar(300) NOT NULL,
  `email_port` varchar(300) NOT NULL,
  `email_user` varchar(300) NOT NULL,
  `email_pass` varchar(300) NOT NULL,
  `wa_otp` text DEFAULT NULL,
  `wa_lulus` text NOT NULL,
  `wa_tidak_lulus` text NOT NULL,
  `wa_cadangan` text NOT NULL,
  `wa_konfbayar_awal` text NOT NULL,
  `wa_konfbayar_akhir` text NOT NULL,
  `wa_suksesbayar` text NOT NULL,
  `nomor_daftar` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `konfigurasi_sistem` (`id`, `api_server`, `api_whatsapp`, `api_ipaymu`, `email`, `email_subject`, `email_host`, `email_port`, `email_user`, `email_pass`, `wa_otp`, `wa_lulus`, `wa_tidak_lulus`, `wa_cadangan`, `wa_konfbayar_awal`, `wa_konfbayar_akhir`, `wa_suksesbayar`, `nomor_daftar`) VALUES (1, 'https://console.wablas.com', 'zqAQ1ofrvtOQQieu4SKnMcS1IeOv6sSXe69Tr02UGagiu1G2HFJcIOQWVfJw5gvD', '3EFF4444-7D58-440A-AC34-D8907A88A7E2', 'noreply@virtuinvite.com', 'PPDB SMK Muhammadiyah 2 Cepu', 'mail.virtuinvite.com', '465', '', 'bismillah99', 'Assalamu\'alaikum JANGAN BERIKAN kode ini kepada siapapun, Berikut ini adalah kode OTP anda: ', 'Assalamualaikum Selamat anda dinyatakan lulus untuk melihat detail silahkan login pada link berikut ini https://ppdb.smkmuhammadiyah2cepu.sch.id/loginsiswa', 'Mohon maaf anda dinyatakan Tidak lulus untuk melihat detail silahkan login pada link berikut ini https://ppdb.smkmuhammadiyah2cepu.sch.id/loginsiswa', 'Mohon maaf anda dinyatakan sebagai Cadangan  untuk melihat detail silahkan login pada link berikut ini https://ppdb.smkmuhammadiyah2cepu.sch.id/loginsiswa', 'Assalamualaikum, Anda sudah berhasil melakukan pendaftaran dengan data sebagai berikut', 'Silahkan melakukan pembayaran pada link yang sudah tertera untuk tahap selanjut nya', 'Pembayaran sudah berhasil silahkan login ke member area calon siswa pada link https://ppdb.smkmuhammadiyah2cepu.sch.id/loginsiswa . Info lebih lanjut hub pusat informasi PPDB : https://wa.me/6282150716903', 'PPDB');


#
# TABLE STRUCTURE FOR: kontak
#

DROP TABLE IF EXISTS `kontak`;

CREATE TABLE `kontak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `whatsapp` text NOT NULL,
  `kontak` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `facebook` text NOT NULL,
  `instagram` text NOT NULL,
  `twitter` text NOT NULL,
  `youtube` text NOT NULL,
  `alamat` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `kontak` (`id`, `whatsapp`, `kontak`, `email`, `facebook`, `instagram`, `twitter`, `youtube`, `alamat`) VALUES (1, '081380515414', 'tel:081380515414', 'Info@alfityanbogor.sch.id', '', '', '', '', 'Jl. Bengkel Roda Kampung Cipicung Desa Mekarsari Kecamatan Cileungsi Kabupaten Bogor Jawa Barat');


#
# TABLE STRUCTURE FOR: kontak_ppdb
#

DROP TABLE IF EXISTS `kontak_ppdb`;

CREATE TABLE `kontak_ppdb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `kontak` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `kontak_ppdb` (`id`, `nama`, `kontak`) VALUES (1, 'Nur Imamah', '0896-3056-2569');
INSERT INTO `kontak_ppdb` (`id`, `nama`, `kontak`) VALUES (3, 'Suharto', '0815-7543-0880');
INSERT INTO `kontak_ppdb` (`id`, `nama`, `kontak`) VALUES (4, 'Sulistyowati', '0813-2570-6953 ');


#
# TABLE STRUCTURE FOR: kontenhome
#

DROP TABLE IF EXISTS `kontenhome`;

CREATE TABLE `kontenhome` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flyer` varchar(100) NOT NULL,
  `video` text NOT NULL,
  `tentang` text NOT NULL,
  `tk` text NOT NULL,
  `sd` text NOT NULL,
  `smp` text NOT NULL,
  `sma` text NOT NULL,
  `link_panduan` text NOT NULL,
  `link_brosur` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `kontenhome` (`id`, `flyer`, `video`, `tentang`, `tk`, `sd`, `smp`, `sma`, `link_panduan`, `link_brosur`) VALUES (1, 'flyer.png', 'https://www.youtube.com/embed/E-L7vgAmVKg?feature=oembed&start&end&wmode=opaque&loop=0&controls=1&mute=0&rel=0&modestbranding=0', 'Al-Fityan Boarding School Bogor (ABSB) adalah cabang ke-6 dari Yayasan Al-Fityan. Hadir di tengah-tengah masyarakat dengan satu konsep pendidikan Islam yang memiliki program Islamic Character Building dan Tahfidz Al-Qur’an menuju terbentuknya generasi pemimpin yang cerdas dan bertaqwa. Dilengkapi fasilitas tenaga pendidik yang profesional, mari bergabung bersama kami. Mendidik dan membentuk putra-putri kita menjadi generasi Islam yang unggul dan bertaqwa.', 'TKIT Al Fityan School Bogor berdiri pada Juli 2017 dibawah naungan Yayasan Al Fityan Indonesia yang dipimpin oleh Syech Ali Sholah Al Zaitir selaku Direktur.', 'SDIT Al Fityan School Bogor berdiri pada Juli 2016 dibawah naungan Yayasan Al Fityan Indonesia yang dipimpin oleh Syech Ali Sholah Al Zaitir selaku Direktur.', 'SMPIT Al Fityan School Bogor berdiri pada Juli 2016 dibawah naungan Yayasan Al Fityan Indonesia yang dipimpin oleh Syech Ali Sholah Al Zaitir selaku Direktur.', 'SMAIT Al Fityan School Bogor berdiri pada Juli 2017 dibawah naungan Yayasan Al Fityan Indonesia yang dipimpin oleh Syech Ali Sholah Al Zaitir selaku Direktur.', '#', '#');


#
# TABLE STRUCTURE FOR: ppdb_call
#

DROP TABLE IF EXISTS `ppdb_call`;

CREATE TABLE `ppdb_call` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kontak` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `ppdb_call` (`id`, `kontak`) VALUES (1, '08173738393911343');
INSERT INTO `ppdb_call` (`id`, `kontak`) VALUES (2, '0899787979912131313');


#
# TABLE STRUCTURE FOR: profil_sekolah
#

DROP TABLE IF EXISTS `profil_sekolah`;

CREATE TABLE `profil_sekolah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `logo` varchar(100) NOT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `telp` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `profil_sekolah` (`id`, `nama`, `logo`, `alamat`, `telp`, `email`) VALUES (1, 'SMK Muhammadiyah 2 Cepu', 'logo_20210420081509.png', 'Jl. Ronggolawe No. 99, Megal\r\nKel. Balun, Kec. Cepu - 58311;\r\nBlora - Jawa Tengah                   ', '0751 - 461692', 'redaksi@smkmuda.com');


#
# TABLE STRUCTURE FOR: setting_buka
#

DROP TABLE IF EXISTS `setting_buka`;

CREATE TABLE `setting_buka` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_buka` date DEFAULT NULL,
  `tgl_tutup` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `setting_buka` (`id`, `tgl_buka`, `tgl_tutup`) VALUES (1, '2021-03-21', '2021-04-30');


#
# TABLE STRUCTURE FOR: siswa
#

DROP TABLE IF EXISTS `siswa`;

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_uniq` text NOT NULL,
  `kode` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(100) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nisn` varchar(100) NOT NULL,
  `nik` varchar(100) NOT NULL,
  `no_kk` varchar(100) NOT NULL,
  `kode_pos` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `jenjang` varchar(100) NOT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `sekolah_asal` varchar(100) NOT NULL,
  `ukuran_seragam` varchar(100) NOT NULL,
  `riwayat_penyakit` varchar(100) NOT NULL,
  `hobi` varchar(150) NOT NULL,
  `foto` text NOT NULL,
  `punya_saudara` varchar(20) NOT NULL,
  `jenjang_saudara` varchar(20) NOT NULL,
  `nama_saudara` varchar(150) NOT NULL,
  `tinggi_badan` varchar(100) NOT NULL,
  `berat_badan` varchar(100) NOT NULL,
  `lingkar_kepala` varchar(100) NOT NULL,
  `anak_ke` int(11) NOT NULL,
  `jml_saudara` int(11) NOT NULL,
  `status_anak` varchar(100) NOT NULL,
  `jalur` varchar(100) DEFAULT NULL,
  `tahun_ajar` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `siswa_tahun_ajar_IDX` (`tahun_ajar`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=292 DEFAULT CHARSET=latin1;

INSERT INTO `siswa` (`id`, `id_uniq`, `kode`, `nama`, `jenis_kelamin`, `whatsapp`, `email`, `nisn`, `nik`, `no_kk`, `kode_pos`, `password`, `jenjang`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `sekolah_asal`, `ukuran_seragam`, `riwayat_penyakit`, `hobi`, `foto`, `punya_saudara`, `jenjang_saudara`, `nama_saudara`, `tinggi_badan`, `berat_badan`, `lingkar_kepala`, `anak_ke`, `jml_saudara`, `status_anak`, `jalur`, `tahun_ajar`) VALUES (284, 'd231adf86f95a63478aedbf0ea42e00b', 'PPDB-0001', 'Siswa TKRO', 'Laki-Laki', '085726674498', 'smkmudacepu@gmail.com', '123456', '335346678888', '64768875444777', '583741', '202cb962ac59075b964b07152d234b70', '7', 'BLORA', '2006-01-17', 'cepu', 'SMP N 2 CEPU', '', '', 'Membaca', 'Siswa_TKRO_20210413011753.png', '', '', '', '', '', '', 0, 0, '', 'reguler', '2');
INSERT INTO `siswa` (`id`, `id_uniq`, `kode`, `nama`, `jenis_kelamin`, `whatsapp`, `email`, `nisn`, `nik`, `no_kk`, `kode_pos`, `password`, `jenjang`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `sekolah_asal`, `ukuran_seragam`, `riwayat_penyakit`, `hobi`, `foto`, `punya_saudara`, `jenjang_saudara`, `nama_saudara`, `tinggi_badan`, `berat_badan`, `lingkar_kepala`, `anak_ke`, `jml_saudara`, `status_anak`, `jalur`, `tahun_ajar`) VALUES (285, 'f64a64966a85efba27b4933843bf82e6', 'PPDB-0285', 'Eka Annas Solichinqqq', 'Laki-Laki', '085729335052', 'annassolichin01@gmail.com', '9090', '23525252512321313', '3402072701060001', '8797', '25d55ad283aa400af464c76d713c07ad', '4', 'Sleman', '1994-06-30', 'Perum. Pring Asri JL Ori No 108 Gunungpring, Muntilan', 'SMP N 3 Muntilan', '', '', 'Sepak Bola', 'Eka_Annas_Solichin_20210418093940.png', '', '', '', '', '', '', 0, 0, '', 'Reguler', '2');
INSERT INTO `siswa` (`id`, `id_uniq`, `kode`, `nama`, `jenis_kelamin`, `whatsapp`, `email`, `nisn`, `nik`, `no_kk`, `kode_pos`, `password`, `jenjang`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `sekolah_asal`, `ukuran_seragam`, `riwayat_penyakit`, `hobi`, `foto`, `punya_saudara`, `jenjang_saudara`, `nama_saudara`, `tinggi_badan`, `berat_badan`, `lingkar_kepala`, `anak_ke`, `jml_saudara`, `status_anak`, `jalur`, `tahun_ajar`) VALUES (287, 'f317b4e9eff1646426dfedf1ddc24861', 'PPDB-0286', 'Eka Annas Solichin', 'Laki-laki', '082150716903', 'technoeka@gmail.com', '707070', '', '', '', '25d55ad283aa400af464c76d713c07ad', '4', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, '', 'Reguler', '2');
INSERT INTO `siswa` (`id`, `id_uniq`, `kode`, `nama`, `jenis_kelamin`, `whatsapp`, `email`, `nisn`, `nik`, `no_kk`, `kode_pos`, `password`, `jenjang`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `sekolah_asal`, `ukuran_seragam`, `riwayat_penyakit`, `hobi`, `foto`, `punya_saudara`, `jenjang_saudara`, `nama_saudara`, `tinggi_badan`, `berat_badan`, `lingkar_kepala`, `anak_ke`, `jml_saudara`, `status_anak`, `jalur`, `tahun_ajar`) VALUES (288, '85a0c57f9010957c96ec5a3bc2bedc28', 'PPDB-0288', 'Diajeng Asma', 'Perempuan', '085743003849', 'annas.ql.prog@gmail.com', '404040', '', '', '', 'e10adc3949ba59abbe56e057f20f883e', '7', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, '', NULL, '2');
INSERT INTO `siswa` (`id`, `id_uniq`, `kode`, `nama`, `jenis_kelamin`, `whatsapp`, `email`, `nisn`, `nik`, `no_kk`, `kode_pos`, `password`, `jenjang`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `sekolah_asal`, `ukuran_seragam`, `riwayat_penyakit`, `hobi`, `foto`, `punya_saudara`, `jenjang_saudara`, `nama_saudara`, `tinggi_badan`, `berat_badan`, `lingkar_kepala`, `anak_ke`, `jml_saudara`, `status_anak`, `jalur`, `tahun_ajar`) VALUES (291, '26b3ed37448f21abd5302fb35388e315', 'PPDB-0289', 'Eka Solichin Annas', 'Laki-Laki', '081231534620', 'devlptenggarong@gmail.com', '30061111', '3308083006940003', '3402072701060001', '56415', '202cb962ac59075b964b07152d234b70', '6', 'Sleman', '1994-06-30', 'Pringgading RT 01, Guwosari, Pajangan, Bantul', 'Sekolah', '', '', 'Hobi', 'Eka_Solichin_Annas_20210421023514.jpg', '', '', '', '', '', '', 0, 0, '', 'Reguler', '2');


#
# TABLE STRUCTURE FOR: siswa_bayar
#

DROP TABLE IF EXISTS `siswa_bayar`;

CREATE TABLE `siswa_bayar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `price` int(11) NOT NULL,
  `urlpayment` text NOT NULL,
  `trx_id` text NOT NULL,
  `sid` text NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_bayar` (`id`, `iduniq`, `tanggal`, `price`, `urlpayment`, `trx_id`, `sid`, `status`) VALUES (216, 'd231adf86f95a63478aedbf0ea42e00b', '2021-04-13 02:47:38', 15000, 'https://my.ipaymu.com/payment/E607BA92-65D5-4E48-B85D-0ACE74CADCA2', '3130199', 'E607BA92-65D5-4E48-B85D-0ACE74CADCA2', 'berhasil');
INSERT INTO `siswa_bayar` (`id`, `iduniq`, `tanggal`, `price`, `urlpayment`, `trx_id`, `sid`, `status`) VALUES (217, 'f64a64966a85efba27b4933843bf82e6', '2021-04-13 03:48:02', 15000, 'https://my.ipaymu.com/payment/8054C7D5-6787-4824-B260-0C16079DE315', '', '8054C7D5-6787-4824-B260-0C16079DE315', 'berhasil');
INSERT INTO `siswa_bayar` (`id`, `iduniq`, `tanggal`, `price`, `urlpayment`, `trx_id`, `sid`, `status`) VALUES (218, 'f317b4e9eff1646426dfedf1ddc24861', '2021-04-13 03:50:26', 15000, 'https://my.ipaymu.com/payment/739C8BFA-8725-418E-AA9C-0F9468309D0B', '', '739C8BFA-8725-418E-AA9C-0F9468309D0B', 'berhasil');
INSERT INTO `siswa_bayar` (`id`, `iduniq`, `tanggal`, `price`, `urlpayment`, `trx_id`, `sid`, `status`) VALUES (220, '85a0c57f9010957c96ec5a3bc2bedc28', '2021-04-13 11:44:01', 15000, 'https://my.ipaymu.com/payment/7FA6F40F-3FF5-4BBA-AFB3-0471A0F794D2', '', '7FA6F40F-3FF5-4BBA-AFB3-0471A0F794D2', '');
INSERT INTO `siswa_bayar` (`id`, `iduniq`, `tanggal`, `price`, `urlpayment`, `trx_id`, `sid`, `status`) VALUES (223, '26b3ed37448f21abd5302fb35388e315', '2021-04-21 02:24:57', 10000, 'https://my.ipaymu.com/payment/C3932CA3-551F-4CC7-B882-7EF9B073EC11', '3177015', 'C3932CA3-551F-4CC7-B882-7EF9B073EC11', 'berhasil');


#
# TABLE STRUCTURE FOR: siswa_bayar_history
#

DROP TABLE IF EXISTS `siswa_bayar_history`;

CREATE TABLE `siswa_bayar_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trx_id` text NOT NULL,
  `sid` text NOT NULL,
  `status` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `user` varchar(100) NOT NULL,
  `siswa` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (183, '3130199', 'E607BA92-65D5-4E48-B85D-0ACE74CADCA2', 'pending', '2021-04-13 02:50:59', '', '');
INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (184, '', '', 'berhasil', '2021-04-13 02:54:30', '1', 'd231adf86f95a63478aedbf0ea42e00b');
INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (185, '', '', 'berhasil', '2021-04-13 06:35:08', '1', 'f64a64966a85efba27b4933843bf82e6');
INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (186, '', '', 'berhasil', '2021-04-20 03:40:47', '18', 'f317b4e9eff1646426dfedf1ddc24861');
INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (187, '3177015', 'C3932CA3-551F-4CC7-B882-7EF9B073EC11', 'pending', '2021-04-21 02:28:20', '', '');
INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (188, '3177015', 'C3932CA3-551F-4CC7-B882-7EF9B073EC11', 'berhasil', '2021-04-21 02:30:13', '', '');


#
# TABLE STRUCTURE FOR: siswa_dokumen
#

DROP TABLE IF EXISTS `siswa_dokumen`;

CREATE TABLE `siswa_dokumen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `type` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=399 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (380, 'd231adf86f95a63478aedbf0ea42e00b', 'Kartu Keluarga', 'kartu_keluarga_123456.png');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (381, 'd231adf86f95a63478aedbf0ea42e00b', 'STTB', 'sttb_123456.png');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (382, 'd231adf86f95a63478aedbf0ea42e00b', 'Akta Kelahiran', 'akta_kelahiran_123456.png');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (383, 'd231adf86f95a63478aedbf0ea42e00b', 'Tidak Mampu', 'tidak_mampu_123456.png');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (387, 'f64a64966a85efba27b4933843bf82e6', 'Tidak Mampu', 'tidak_mampu_9090.jpg');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (396, '26b3ed37448f21abd5302fb35388e315', 'Kartu Keluarga', 'kartu_keluarga_30061111.png');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (397, '26b3ed37448f21abd5302fb35388e315', 'Akta Kelahiran', 'akta_kelahiran_30061111.pdf');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (398, '26b3ed37448f21abd5302fb35388e315', 'STTB', 'sttb_30061111.pdf');


#
# TABLE STRUCTURE FOR: siswa_kelas
#

DROP TABLE IF EXISTS `siswa_kelas`;

CREATE TABLE `siswa_kelas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kelas_id` varchar(100) DEFAULT NULL,
  `siswa_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `siswa_kelas_kelas_id_IDX` (`kelas_id`,`siswa_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_kelas` (`id`, `kelas_id`, `siswa_id`) VALUES (5, '2', 'PPDB-0001');
INSERT INTO `siswa_kelas` (`id`, `kelas_id`, `siswa_id`) VALUES (13, '2', 'PPDB-0285');
INSERT INTO `siswa_kelas` (`id`, `kelas_id`, `siswa_id`) VALUES (15, '6', 'PPDB-0289');


#
# TABLE STRUCTURE FOR: siswa_orangtua
#

DROP TABLE IF EXISTS `siswa_orangtua`;

CREATE TABLE `siswa_orangtua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `nama_ayah` varchar(200) NOT NULL,
  `pend_ayah` varchar(100) NOT NULL,
  `pekerjaan_ayah` varchar(200) NOT NULL,
  `pekerjaan_ayah_lain` text NOT NULL,
  `nik_ayah` varchar(200) NOT NULL,
  `tmp_lhr_ayah` varchar(200) NOT NULL,
  `tgl_lhr_ayah` date NOT NULL,
  `nomor_ayah` varchar(200) NOT NULL,
  `penghasilan_ayah` varchar(200) NOT NULL,
  `nama_ibu` varchar(200) NOT NULL,
  `pend_ibu` varchar(200) NOT NULL,
  `pekerjaan_ibu` varchar(200) NOT NULL,
  `pekerjaan_ibu_lain` text NOT NULL,
  `nik_ibu` varchar(200) NOT NULL,
  `tmp_lhr_ibu` varchar(200) NOT NULL,
  `tgl_lhr_ibu` date NOT NULL,
  `nomor_ibu` varchar(200) NOT NULL,
  `penghasilan_ibu` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_orangtua` (`id`, `iduniq`, `nama_ayah`, `pend_ayah`, `pekerjaan_ayah`, `pekerjaan_ayah_lain`, `nik_ayah`, `tmp_lhr_ayah`, `tgl_lhr_ayah`, `nomor_ayah`, `penghasilan_ayah`, `nama_ibu`, `pend_ibu`, `pekerjaan_ibu`, `pekerjaan_ibu_lain`, `nik_ibu`, `tmp_lhr_ibu`, `tgl_lhr_ibu`, `nomor_ibu`, `penghasilan_ibu`) VALUES (59, 'd231adf86f95a63478aedbf0ea42e00b', 'Alm. ROBERT HUTTING', 'SMA', 'Wiraswasta', '', '6453454354333', 'Bnvhhh', '1965-07-08', '0865444566666', '5000000', 'ARUM KURNIASIH', 'SMA', 'Ibu Rumah Tangga', '', '65434677575765', 'Bkhhhgg', '1965-07-08', '0865444566666', 'Tidak Berpenghasilan');
INSERT INTO `siswa_orangtua` (`id`, `iduniq`, `nama_ayah`, `pend_ayah`, `pekerjaan_ayah`, `pekerjaan_ayah_lain`, `nik_ayah`, `tmp_lhr_ayah`, `tgl_lhr_ayah`, `nomor_ayah`, `penghasilan_ayah`, `nama_ibu`, `pend_ibu`, `pekerjaan_ibu`, `pekerjaan_ibu_lain`, `nik_ibu`, `tmp_lhr_ibu`, `tgl_lhr_ibu`, `nomor_ibu`, `penghasilan_ibu`) VALUES (60, 'f64a64966a85efba27b4933843bf82e6', 'Widjanarkoqqq', 'S2', 'Dokter', '', '3308083006940003000', 'Slemanqqq', '2021-03-24', '08174641111', '10000000', 'qqqq', 'S1', 'Dokter', '', ' 34020704096100010', 'Slemanqqq', '2021-03-24', '456546411111', '10000000');
INSERT INTO `siswa_orangtua` (`id`, `iduniq`, `nama_ayah`, `pend_ayah`, `pekerjaan_ayah`, `pekerjaan_ayah_lain`, `nik_ayah`, `tmp_lhr_ayah`, `tgl_lhr_ayah`, `nomor_ayah`, `penghasilan_ayah`, `nama_ibu`, `pend_ibu`, `pekerjaan_ibu`, `pekerjaan_ibu_lain`, `nik_ibu`, `tmp_lhr_ibu`, `tgl_lhr_ibu`, `nomor_ibu`, `penghasilan_ibu`) VALUES (61, '26b3ed37448f21abd5302fb35388e315', 'Ayah Annas', 'S1', 'Wiraswasta', '', '98098098098', 'Tempat Lahir Ayah Annas', '1979-03-23', '00001111', '5000000', 'Ibu Annas', 'S1', 'Wiraswasta', '', '98098098091', 'Tempat Lahir Ibu Annas', '1979-04-30', '456546411111', 'Tidak Berpenghasilan');


#
# TABLE STRUCTURE FOR: siswa_otp
#

DROP TABLE IF EXISTS `siswa_otp`;

CREATE TABLE `siswa_otp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `otp` varchar(100) DEFAULT NULL,
  `nomor` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (37, '545777', '085726674498', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (38, '878545', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (39, '086105', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (40, '786501', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (41, '033475', '082150716903', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (42, '618431', '082150716903', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (43, '231636', '085743003849', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (44, '827642', '085743003849', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (45, '634361', '085743003849', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (46, '250024', '085743003849', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (47, '976003', '085743003849', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (48, '377407', '081231534620', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (49, '115044', '081231534620', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (50, '174564', '081231534620', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (51, '324641', '081231534620', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (52, '600686', '081231534620', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (53, '017176', '081231534620', '1');


#
# TABLE STRUCTURE FOR: siswa_pengumuman
#

DROP TABLE IF EXISTS `siswa_pengumuman`;

CREATE TABLE `siswa_pengumuman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `nilai` int(11) NOT NULL,
  `status` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_pengumuman` (`id`, `iduniq`, `nilai`, `status`) VALUES (24, 'd231adf86f95a63478aedbf0ea42e00b', 0, 'Lulus');
INSERT INTO `siswa_pengumuman` (`id`, `iduniq`, `nilai`, `status`) VALUES (25, 'f64a64966a85efba27b4933843bf82e6', 0, 'Lulus');
INSERT INTO `siswa_pengumuman` (`id`, `iduniq`, `nilai`, `status`) VALUES (26, 'f317b4e9eff1646426dfedf1ddc24861', 0, 'Lulus');
INSERT INTO `siswa_pengumuman` (`id`, `iduniq`, `nilai`, `status`) VALUES (27, '85a0c57f9010957c96ec5a3bc2bedc28', 0, 'Lulus');
INSERT INTO `siswa_pengumuman` (`id`, `iduniq`, `nilai`, `status`) VALUES (28, '26b3ed37448f21abd5302fb35388e315', 0, 'Lulus');


#
# TABLE STRUCTURE FOR: siswa_prestasi
#

DROP TABLE IF EXISTS `siswa_prestasi`;

CREATE TABLE `siswa_prestasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `prestasi` varchar(500) NOT NULL,
  `file` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_prestasi` (`id`, `iduniq`, `prestasi`, `file`) VALUES (77, 'f64a64966a85efba27b4933843bf82e6', 'tes', 'Prestasi_tes_20210420030047.pdf');
INSERT INTO `siswa_prestasi` (`id`, `iduniq`, `prestasi`, `file`) VALUES (83, '26b3ed37448f21abd5302fb35388e315', 'Juara 1 Lomba Makan', 'Prestasi_Juara_1_Lomba_Makan_20210421023725.pdf');
INSERT INTO `siswa_prestasi` (`id`, `iduniq`, `prestasi`, `file`) VALUES (84, '26b3ed37448f21abd5302fb35388e315', 'Juara 1 Lomba Tidur', 'Prestasi_Juara_1_Lomba_Tidur_20210421023749.png');


#
# TABLE STRUCTURE FOR: siswa_ujian
#

DROP TABLE IF EXISTS `siswa_ujian`;

CREATE TABLE `siswa_ujian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `idjadwal` text NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_ujian` (`id`, `iduniq`, `idjadwal`, `tanggal`) VALUES (183, 'd231adf86f95a63478aedbf0ea42e00b', '71', '0000-00-00');
INSERT INTO `siswa_ujian` (`id`, `iduniq`, `idjadwal`, `tanggal`) VALUES (184, 'f64a64966a85efba27b4933843bf82e6', '70', '0000-00-00');
INSERT INTO `siswa_ujian` (`id`, `iduniq`, `idjadwal`, `tanggal`) VALUES (185, '26b3ed37448f21abd5302fb35388e315', '72', '0000-00-00');


#
# TABLE STRUCTURE FOR: syarat_administrasi
#

DROP TABLE IF EXISTS `syarat_administrasi`;

CREATE TABLE `syarat_administrasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (2, 'Menyerahkan foto copy STTB SMP / MTs sederajat, (bisa menyusul) atau membawa kartu peserta Ujian Nasional (UN)');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (3, 'Menyerahkan pas foto ukuran 3 x 4 (2 lembar)');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (4, 'Foto copy Kartu Keluarga (KK)');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (5, 'Foto copy AKTE kelahiran');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (6, 'Usia maksimal 21 tahun');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (7, 'Tidak bertato / bertindik');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (8, 'Tidak pernah tersangkut tindakan pidana');


#
# TABLE STRUCTURE FOR: tahun_akademik
#

DROP TABLE IF EXISTS `tahun_akademik`;

CREATE TABLE `tahun_akademik` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tahun` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tahun_akademik` (`id`, `tahun`, `status`) VALUES (2, '2021/2022', 'Aktif');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_uniq` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `username` varchar(100) NOT NULL,
  `foto` text NOT NULL,
  `level` varchar(150) NOT NULL,
  `jenjang` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `user` (`id`, `id_uniq`, `email`, `password`, `username`, `foto`, `level`, `jenjang`) VALUES (1, 'c4ca4238a0b923820dcc509a6f75849b', 'adminsistem@gmail.com', '25d55ad283aa400af464c76d713c07ad', 'Administrator', 'Administrator_20210320111533.png', 'Administrator', NULL);
INSERT INTO `user` (`id`, `id_uniq`, `email`, `password`, `username`, `foto`, `level`, `jenjang`) VALUES (18, '090741fad73e473fe50d804ad669dfab', 'admintro@gmail.com', '25d55ad283aa400af464c76d713c07ad', 'admintroa', 'admintro_20210420015428.png', 'Jenjang', '4');
INSERT INTO `user` (`id`, `id_uniq`, `email`, `password`, `username`, `foto`, `level`, `jenjang`) VALUES (19, '048558286f3aafae72eb77b7bb1ab7ca', 'technoeka@gmail.com', '202cb962ac59075b964b07152d234b70', 'Eka Annas', '', 'Administrator', '');
INSERT INTO `user` (`id`, `id_uniq`, `email`, `password`, `username`, `foto`, `level`, `jenjang`) VALUES (20, 'bafd6afb82c8868d0833c341191fdf28', 'annassolichin01@gmail.com', '25d55ad283aa400af464c76d713c07ad', 'Annas', '', 'Jenjang', '6');


#
# TABLE STRUCTURE FOR: v_jadwal
#

DROP TABLE IF EXISTS `v_jadwal`;

CREATE ALGORITHM=MERGE DEFINER=`smkmuha2_ppdb`@`%` SQL SECURITY DEFINER VIEW `v_jadwal` AS select `b`.`kode` AS `kode`,`b`.`jenis_kelamin` AS `jenis_kelamin`,`b`.`whatsapp` AS `whatsapp`,`b`.`jenjang` AS `jenjang`,`a`.`iduniq` AS `iduniq`,`b`.`id` AS `id`,`a`.`sid` AS `sid`,`a`.`trx_id` AS `trx_id`,date_format(`a`.`tanggal`,'%d/%m/%Y %h:%i') AS `tanggal`,`a`.`price` AS `price`,`b`.`nama` AS `nama`,`b`.`email` AS `email`,`a`.`status` AS `status`,date_format(`c`.`tanggal`,'%d/%m/%Y') AS `tanggal_ujian` from ((`siswa_bayar` `a` join `siswa` `b` on(`b`.`id_uniq` = `a`.`iduniq`)) left join `siswa_ujian` `c` on(`c`.`iduniq` = `a`.`iduniq`));

utf8mb4_general_ci;

INSERT INTO `v_jadwal` (`kode`, `jenis_kelamin`, `whatsapp`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `tanggal_ujian`) VALUES ('PPDB-0001', 'Laki-Laki', '085726674498', '7', 'd231adf86f95a63478aedbf0ea42e00b', 284, 'E607BA92-65D5-4E48-B85D-0ACE74CADCA2', '3130199', '13/04/2021 02:47', 15000, 'Siswa TKRO', 'smkmudacepu@gmail.com', 'berhasil', '00/00/0000');
INSERT INTO `v_jadwal` (`kode`, `jenis_kelamin`, `whatsapp`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `tanggal_ujian`) VALUES ('PPDB-0285', 'Laki-Laki', '085729335052', '4', 'f64a64966a85efba27b4933843bf82e6', 285, '8054C7D5-6787-4824-B260-0C16079DE315', '', '13/04/2021 03:48', 15000, 'Eka Annas Solichinqqq', 'annassolichin01@gmail.com', 'berhasil', '00/00/0000');
INSERT INTO `v_jadwal` (`kode`, `jenis_kelamin`, `whatsapp`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `tanggal_ujian`) VALUES ('PPDB-0286', 'Laki-laki', '082150716903', '4', 'f317b4e9eff1646426dfedf1ddc24861', 287, '739C8BFA-8725-418E-AA9C-0F9468309D0B', '', '13/04/2021 03:50', 15000, 'Eka Annas Solichin', 'technoeka@gmail.com', 'berhasil', NULL);
INSERT INTO `v_jadwal` (`kode`, `jenis_kelamin`, `whatsapp`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `tanggal_ujian`) VALUES ('PPDB-0288', 'Perempuan', '085743003849', '7', '85a0c57f9010957c96ec5a3bc2bedc28', 288, '7FA6F40F-3FF5-4BBA-AFB3-0471A0F794D2', '', '13/04/2021 11:44', 15000, 'Diajeng Asma', 'annas.ql.prog@gmail.com', '', NULL);
INSERT INTO `v_jadwal` (`kode`, `jenis_kelamin`, `whatsapp`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `tanggal_ujian`) VALUES ('PPDB-0289', 'Laki-Laki', '081231534620', '6', '26b3ed37448f21abd5302fb35388e315', 291, 'C3932CA3-551F-4CC7-B882-7EF9B073EC11', '3177015', '21/04/2021 02:24', 10000, 'Eka Solichin Annas', 'devlptenggarong@gmail.com', 'berhasil', '00/00/0000');


#
# TABLE STRUCTURE FOR: v_jadwalujian
#

DROP TABLE IF EXISTS `v_jadwalujian`;

CREATE ALGORITHM=UNDEFINED DEFINER=`smkmuha2_ppdb`@`%` SQL SECURITY DEFINER VIEW `v_jadwalujian` AS select `a`.`id` AS `id`,`a`.`nama_tes` AS `nama_tes`,`a`.`jenjang` AS `jenjang`,`a`.`keterangan` AS `keterangan`,`a`.`kuota` AS `kuota`,(select count(`siswa_ujian`.`id`) from `siswa_ujian` where `siswa_ujian`.`idjadwal` = `a`.`id`) AS `jumlah_peserta`,dayname(`a`.`tanggal`) AS `tanggal_day`,date_format(`a`.`tanggal`,'%d/%m/%Y') AS `tanggal` from `jadwal` `a`;

utf8mb4_general_ci;

INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (27, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SDIT', 'Offline', 20, '0', 'Saturday', '13/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (28, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT', 'Online', 5, '0', 'Wednesday', '03/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (29, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT', 'Online', 5, '0', 'Thursday', '04/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (30, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT', 'Online', 5, '0', 'Friday', '05/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (31, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT', 'Online', 10, '0', 'Saturday', '06/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (32, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 5, '0', 'Wednesday', '03/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (33, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 5, '0', 'Thursday', '04/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (34, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 5, '0', 'Friday', '05/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (35, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 5, '0', 'Saturday', '06/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (36, '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', 'TKIT', 'Offline', 2, '0', 'Sunday', '07/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (37, '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', 'TKIT', 'Offline', 20, '0', 'Saturday', '13/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (40, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 5, '0', 'Thursday', '11/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (41, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 5, '0', 'Friday', '12/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (42, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT', 'Online', 5, '0', 'Thursday', '11/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (43, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT', 'Online', 5, '0', 'Friday', '12/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (44, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT', 'Online', 10, '0', 'Saturday', '13/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (45, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 10, '0', 'Saturday', '13/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (47, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT Quran', 'Offline', 20, '0', 'Saturday', '27/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (48, '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', 'TKIT A', 'Offline', 20, '0', 'Saturday', '27/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (49, '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', 'TKIT B', 'Offline', 20, '0', 'Saturday', '27/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (50, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SDIT', 'Offline', 20, '0', 'Saturday', '27/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (51, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT Akademik', 'Online', 10, '0', 'Thursday', '18/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (52, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT Akademik', 'Online', 10, '0', 'Friday', '19/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (53, '-test akademik <br> -test baca iqro<br>test psikologi<br> -wawancara', 'SMAIT', 'Online', 1, '0', 'Monday', '01/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (54, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 10, '0', 'Wednesday', '24/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (55, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 10, '0', 'Thursday', '25/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (56, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 10, '0', 'Friday', '26/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (57, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT Akademik', 'Online', 10, '0', 'Friday', '26/02/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (58, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT Akademik', 'Online', 10, '0', 'Wednesday', '03/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (59, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT Akademik', 'Online', 10, '0', 'Thursday', '04/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (60, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT Akademik', 'Online', 10, '0', 'Friday', '05/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (61, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT Akademik', 'Online', 10, '0', 'Saturday', '06/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (62, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 10, '0', 'Wednesday', '03/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (63, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 10, '0', 'Thursday', '04/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (64, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 10, '0', 'Friday', '05/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (65, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMAIT', 'Online', 10, '0', 'Saturday', '06/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (66, '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', 'SMPIT Quran', 'Offline', 20, '0', 'Saturday', '06/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (67, 'TES AWAL', 'TKIT A', 'Online', 90, '0', 'Thursday', '11/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (68, 'TES AWAL', 'TKIT B', 'Online', 90, '0', 'Thursday', '11/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (69, 'TES AWAL', '5', 'Offline', 100, '0', 'Wednesday', '31/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (70, 'Tes Kecakapan', '4', 'Offline', 100, '1', 'Wednesday', '31/03/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (71, 'TES FISIK', '7', 'Offline', 35, '1', 'Thursday', '15/04/2021');
INSERT INTO `v_jadwalujian` (`id`, `nama_tes`, `jenjang`, `keterangan`, `kuota`, `jumlah_peserta`, `tanggal_day`, `tanggal`) VALUES (72, 'Tes Kecakapan', '6', 'Offline', 100, '1', 'Friday', '30/04/2021');


#
# TABLE STRUCTURE FOR: v_jadwalujian2
#

DROP TABLE IF EXISTS `v_jadwalujian2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`smkmuha2_ppdb`@`%` SQL SECURITY DEFINER VIEW `v_jadwalujian2` AS select `a`.`id` AS `id`,`a`.`nama_tes` AS `nama_tes`,`a`.`jenjang` AS `jenjang`,`a`.`keterangan` AS `keterangan`,`a`.`kuota` AS `kuota`,(select count(`siswa_ujian`.`id`) from `siswa_ujian` where `siswa_ujian`.`idjadwal` = `a`.`id`) AS `jumlah_peserta`,dayname(`a`.`tanggal`) AS `tanggal_day`,date_format(`a`.`tanggal`,'%d/%m/%Y') AS `tanggal` from `jadwal` `a` where `a`.`tanggal` = curdate();

utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: v_pembayaran
#

DROP TABLE IF EXISTS `v_pembayaran`;

CREATE ALGORITHM=UNDEFINED DEFINER=`smkmuha2_ppdb`@`%` SQL SECURITY DEFINER VIEW `v_pembayaran` AS select `b`.`jenjang` AS `jenjang`,`a`.`iduniq` AS `iduniq`,`a`.`id` AS `id`,`a`.`sid` AS `sid`,`a`.`trx_id` AS `trx_id`,date_format(`a`.`tanggal`,'%d/%m/%Y %h:%i') AS `tanggal`,`a`.`price` AS `price`,`b`.`nama` AS `nama`,`b`.`email` AS `email`,`a`.`status` AS `status` from (`siswa_bayar` `a` join `siswa` `b` on(`b`.`id_uniq` = `a`.`iduniq`));

utf8mb4_general_ci;

INSERT INTO `v_pembayaran` (`jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`) VALUES ('7', 'd231adf86f95a63478aedbf0ea42e00b', 216, 'E607BA92-65D5-4E48-B85D-0ACE74CADCA2', '3130199', '13/04/2021 02:47', 15000, 'Siswa TKRO', 'smkmudacepu@gmail.com', 'berhasil');
INSERT INTO `v_pembayaran` (`jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`) VALUES ('4', 'f64a64966a85efba27b4933843bf82e6', 217, '8054C7D5-6787-4824-B260-0C16079DE315', '', '13/04/2021 03:48', 15000, 'Eka Annas Solichinqqq', 'annassolichin01@gmail.com', 'berhasil');
INSERT INTO `v_pembayaran` (`jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`) VALUES ('4', 'f317b4e9eff1646426dfedf1ddc24861', 218, '739C8BFA-8725-418E-AA9C-0F9468309D0B', '', '13/04/2021 03:50', 15000, 'Eka Annas Solichin', 'technoeka@gmail.com', 'berhasil');
INSERT INTO `v_pembayaran` (`jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`) VALUES ('7', '85a0c57f9010957c96ec5a3bc2bedc28', 220, '7FA6F40F-3FF5-4BBA-AFB3-0471A0F794D2', '', '13/04/2021 11:44', 15000, 'Diajeng Asma', 'annas.ql.prog@gmail.com', '');
INSERT INTO `v_pembayaran` (`jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`) VALUES ('6', '26b3ed37448f21abd5302fb35388e315', 223, 'C3932CA3-551F-4CC7-B882-7EF9B073EC11', '3177015', '21/04/2021 02:24', 10000, 'Eka Solichin Annas', 'devlptenggarong@gmail.com', 'berhasil');


#
# TABLE STRUCTURE FOR: v_pembayaran2
#

DROP TABLE IF EXISTS `v_pembayaran2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`smkmuha2_ppdb`@`%` SQL SECURITY DEFINER VIEW `v_pembayaran2` AS (select `b`.`jenjang` AS `jenjang`,`a`.`iduniq` AS `iduniq`,`a`.`id` AS `id`,`a`.`sid` AS `sid`,`a`.`trx_id` AS `trx_id`,`a`.`tanggal` AS `tanggaldate`,date_format(`a`.`tanggal`,'%d/%m/%Y %h:%i') AS `tanggal`,`a`.`price` AS `price`,`b`.`nama` AS `nama`,`b`.`email` AS `email`,`b`.`whatsapp` AS `whatsapp`,`a`.`status` AS `status` from (`siswa_bayar` `a` join `siswa` `b` on(`b`.`id_uniq` = `a`.`iduniq`)));

utf8mb4_general_ci;

INSERT INTO `v_pembayaran2` (`jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggaldate`, `tanggal`, `price`, `nama`, `email`, `whatsapp`, `status`) VALUES ('7', 'd231adf86f95a63478aedbf0ea42e00b', 216, 'E607BA92-65D5-4E48-B85D-0ACE74CADCA2', '3130199', '2021-04-13 02:47:38', '13/04/2021 02:47', 15000, 'Siswa TKRO', 'smkmudacepu@gmail.com', '085726674498', 'berhasil');
INSERT INTO `v_pembayaran2` (`jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggaldate`, `tanggal`, `price`, `nama`, `email`, `whatsapp`, `status`) VALUES ('4', 'f64a64966a85efba27b4933843bf82e6', 217, '8054C7D5-6787-4824-B260-0C16079DE315', '', '2021-04-13 03:48:02', '13/04/2021 03:48', 15000, 'Eka Annas Solichinqqq', 'annassolichin01@gmail.com', '085729335052', 'berhasil');
INSERT INTO `v_pembayaran2` (`jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggaldate`, `tanggal`, `price`, `nama`, `email`, `whatsapp`, `status`) VALUES ('4', 'f317b4e9eff1646426dfedf1ddc24861', 218, '739C8BFA-8725-418E-AA9C-0F9468309D0B', '', '2021-04-13 03:50:26', '13/04/2021 03:50', 15000, 'Eka Annas Solichin', 'technoeka@gmail.com', '082150716903', 'berhasil');
INSERT INTO `v_pembayaran2` (`jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggaldate`, `tanggal`, `price`, `nama`, `email`, `whatsapp`, `status`) VALUES ('7', '85a0c57f9010957c96ec5a3bc2bedc28', 220, '7FA6F40F-3FF5-4BBA-AFB3-0471A0F794D2', '', '2021-04-13 11:44:01', '13/04/2021 11:44', 15000, 'Diajeng Asma', 'annas.ql.prog@gmail.com', '085743003849', '');
INSERT INTO `v_pembayaran2` (`jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggaldate`, `tanggal`, `price`, `nama`, `email`, `whatsapp`, `status`) VALUES ('6', '26b3ed37448f21abd5302fb35388e315', 223, 'C3932CA3-551F-4CC7-B882-7EF9B073EC11', '3177015', '2021-04-21 02:24:57', '21/04/2021 02:24', 10000, 'Eka Solichin Annas', 'devlptenggarong@gmail.com', '081231534620', 'berhasil');


#
# TABLE STRUCTURE FOR: v_pengumuman
#

DROP TABLE IF EXISTS `v_pengumuman`;

CREATE ALGORITHM=UNDEFINED DEFINER=`smkmuha2_ppdb`@`%` SQL SECURITY DEFINER VIEW `v_pengumuman` AS select `b`.`kode` AS `kode`,`b`.`jenis_kelamin` AS `jenis_kelamin`,`b`.`jenjang` AS `jenjang`,`a`.`iduniq` AS `iduniq`,`b`.`id` AS `id`,`a`.`sid` AS `sid`,`a`.`trx_id` AS `trx_id`,date_format(`a`.`tanggal`,'%d/%m/%Y %h:%i') AS `tanggal`,`a`.`price` AS `price`,`b`.`nama` AS `nama`,`b`.`email` AS `email`,`a`.`status` AS `status`,`c`.`nilai` AS `nilai`,`c`.`status` AS `status_lulus`,`b`.`jalur` AS `jalur`,`d`.`kelas_id` AS `kelas_id` from (((`siswa_bayar` `a` join `siswa` `b` on(`b`.`id_uniq` = `a`.`iduniq`)) left join `siswa_pengumuman` `c` on(`c`.`iduniq` = `a`.`iduniq`)) left join `siswa_kelas` `d` on(`d`.`siswa_id` = `b`.`kode`));

utf8mb4_general_ci;

INSERT INTO `v_pengumuman` (`kode`, `jenis_kelamin`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `nilai`, `status_lulus`, `jalur`, `kelas_id`) VALUES ('PPDB-0001', 'Laki-Laki', '7', 'd231adf86f95a63478aedbf0ea42e00b', 284, 'E607BA92-65D5-4E48-B85D-0ACE74CADCA2', '3130199', '13/04/2021 02:47', 15000, 'Siswa TKRO', 'smkmudacepu@gmail.com', 'berhasil', 0, 'Lulus', 'reguler', '2');
INSERT INTO `v_pengumuman` (`kode`, `jenis_kelamin`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `nilai`, `status_lulus`, `jalur`, `kelas_id`) VALUES ('PPDB-0285', 'Laki-Laki', '4', 'f64a64966a85efba27b4933843bf82e6', 285, '8054C7D5-6787-4824-B260-0C16079DE315', '', '13/04/2021 03:48', 15000, 'Eka Annas Solichinqqq', 'annassolichin01@gmail.com', 'berhasil', 0, 'Lulus', 'Reguler', '2');
INSERT INTO `v_pengumuman` (`kode`, `jenis_kelamin`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `nilai`, `status_lulus`, `jalur`, `kelas_id`) VALUES ('PPDB-0289', 'Laki-Laki', '6', '26b3ed37448f21abd5302fb35388e315', 291, 'C3932CA3-551F-4CC7-B882-7EF9B073EC11', '3177015', '21/04/2021 02:24', 10000, 'Eka Solichin Annas', 'devlptenggarong@gmail.com', 'berhasil', 0, 'Lulus', 'Reguler', '6');
INSERT INTO `v_pengumuman` (`kode`, `jenis_kelamin`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `nilai`, `status_lulus`, `jalur`, `kelas_id`) VALUES ('PPDB-0286', 'Laki-laki', '4', 'f317b4e9eff1646426dfedf1ddc24861', 287, '739C8BFA-8725-418E-AA9C-0F9468309D0B', '', '13/04/2021 03:50', 15000, 'Eka Annas Solichin', 'technoeka@gmail.com', 'berhasil', 0, 'Lulus', 'Reguler', NULL);
INSERT INTO `v_pengumuman` (`kode`, `jenis_kelamin`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `nilai`, `status_lulus`, `jalur`, `kelas_id`) VALUES ('PPDB-0288', 'Perempuan', '7', '85a0c57f9010957c96ec5a3bc2bedc28', 288, '7FA6F40F-3FF5-4BBA-AFB3-0471A0F794D2', '', '13/04/2021 11:44', 15000, 'Diajeng Asma', 'annas.ql.prog@gmail.com', '', 0, 'Lulus', NULL, NULL);


#
# TABLE STRUCTURE FOR: v_setjadwal
#

DROP TABLE IF EXISTS `v_setjadwal`;

CREATE ALGORITHM=UNDEFINED DEFINER=`smkmuha2_ppdb`@`%` SQL SECURITY DEFINER VIEW `v_setjadwal` AS select `a`.`kode` AS `kode`,`a`.`nama` AS `nama`,`a`.`jenis_kelamin` AS `jenis_kelamin`,`a`.`email` AS `email`,`a`.`jenjang` AS `jenjang`,`b`.`idjadwal` AS `idjadwal` from (`siswa` `a` left join `siswa_ujian` `b` on(`b`.`iduniq` = `a`.`id_uniq`)) where `b`.`idjadwal` is null;

utf8mb4_general_ci;

INSERT INTO `v_setjadwal` (`kode`, `nama`, `jenis_kelamin`, `email`, `jenjang`, `idjadwal`) VALUES ('PPDB-0286', 'Eka Annas Solichin', 'Laki-laki', 'technoeka@gmail.com', '4', NULL);
INSERT INTO `v_setjadwal` (`kode`, `nama`, `jenis_kelamin`, `email`, `jenjang`, `idjadwal`) VALUES ('PPDB-0288', 'Diajeng Asma', 'Perempuan', 'annas.ql.prog@gmail.com', '7', NULL);


#
# TABLE STRUCTURE FOR: v_ujiansiswa
#

DROP TABLE IF EXISTS `v_ujiansiswa`;

CREATE ALGORITHM=UNDEFINED DEFINER=`smkmuha2_ppdb`@`%` SQL SECURITY DEFINER VIEW `v_ujiansiswa` AS select `siswa`.`id_uniq` AS `id_uniq`,`siswa_ujian`.`id` AS `id`,`siswa`.`jenis_kelamin` AS `jenis_kelamin`,`siswa_ujian`.`idjadwal` AS `idjadwal`,`siswa`.`nisn` AS `nisn`,`siswa`.`nama` AS `nama`,`siswa`.`jenjang` AS `jenjang`,(select `jenjang`.`nama` from `jenjang` where `jenjang`.`id` = `siswa`.`jenjang`) AS `jenjang_nama`,`siswa`.`kode` AS `kode`,(select `jadwal`.`nama_tes` from `jadwal` where `jadwal`.`id` = `siswa_ujian`.`idjadwal`) AS `nama_tes`,(select `jadwal`.`keterangan` from `jadwal` where `jadwal`.`id` = `siswa_ujian`.`idjadwal`) AS `keterangan`,(select date_format(`jadwal`.`tanggal`,'%d/%m/%Y') from `jadwal` where `jadwal`.`id` = `siswa_ujian`.`idjadwal`) AS `tanggal_ujian`,(select dayname(`jadwal`.`tanggal`) from `jadwal` where `jadwal`.`id` = `siswa_ujian`.`idjadwal`) AS `hari_ujian` from (`siswa_ujian` left join `siswa` on(`siswa`.`id_uniq` = `siswa_ujian`.`iduniq`));

utf8mb4_general_ci;

INSERT INTO `v_ujiansiswa` (`id_uniq`, `id`, `jenis_kelamin`, `idjadwal`, `nisn`, `nama`, `jenjang`, `jenjang_nama`, `kode`, `nama_tes`, `keterangan`, `tanggal_ujian`, `hari_ujian`) VALUES ('d231adf86f95a63478aedbf0ea42e00b', 183, 'Laki-Laki', '71', '123456', 'Siswa TKRO', '7', 'Asisten Keperawatan', 'PPDB-0001', 'TES FISIK', 'Offline', '15/04/2021', 'Thursday');
INSERT INTO `v_ujiansiswa` (`id_uniq`, `id`, `jenis_kelamin`, `idjadwal`, `nisn`, `nama`, `jenjang`, `jenjang_nama`, `kode`, `nama_tes`, `keterangan`, `tanggal_ujian`, `hari_ujian`) VALUES ('f64a64966a85efba27b4933843bf82e6', 184, 'Laki-Laki', '70', '9090', 'Eka Annas Solichinqqq', '4', 'Teknik Kendaraan Ringan (Otomotif)', 'PPDB-0285', 'Tes Kecakapan', 'Offline', '31/03/2021', 'Wednesday');
INSERT INTO `v_ujiansiswa` (`id_uniq`, `id`, `jenis_kelamin`, `idjadwal`, `nisn`, `nama`, `jenjang`, `jenjang_nama`, `kode`, `nama_tes`, `keterangan`, `tanggal_ujian`, `hari_ujian`) VALUES ('26b3ed37448f21abd5302fb35388e315', 185, 'Laki-Laki', '72', '30061111', 'Eka Solichin Annas', '6', 'Teknik Bisnis & Sepeda Motor', 'PPDB-0289', 'Tes Kecakapan', 'Offline', '30/04/2021', 'Friday');


