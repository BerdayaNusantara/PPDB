#
# TABLE STRUCTURE FOR: alasan
#

DROP TABLE IF EXISTS `alasan`;

CREATE TABLE `alasan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `alasan` (`id`, `judul`, `deskripsi`) VALUES (1, 'Alasan A', 'Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi');
INSERT INTO `alasan` (`id`, `judul`, `deskripsi`) VALUES (2, 'Alasan B', 'Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi');
INSERT INTO `alasan` (`id`, `judul`, `deskripsi`) VALUES (3, 'Alasan C', 'Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi');
INSERT INTO `alasan` (`id`, `judul`, `deskripsi`) VALUES (4, 'Alasan D', 'Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi');


#
# TABLE STRUCTURE FOR: alur_pendaftaran
#

DROP TABLE IF EXISTS `alur_pendaftaran`;

CREATE TABLE `alur_pendaftaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `keterangan` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `alur_pendaftaran` (`id`, `nama`, `tanggal`, `keterangan`) VALUES (2, 'Akses situs', '2021-02-01', 'Calon santri dan wali santri wajib membaca semua hal yang berkaitan dengan Pendaftaran Santri Baru (PSB) Pesantren Modern Al-Manar, mulai dari Syarat Pendaftaran, Syarat Administrasi, Jadwal Pendaftaran dan Tata Cara Pandaftaran dengan mengakses hala');
INSERT INTO `alur_pendaftaran` (`id`, `nama`, `tanggal`, `keterangan`) VALUES (3, 'Tunggu Konfirmasi dari Panitia', '2021-03-01', 'Tunggu hingga mendapatkan notifikasi pesan dari Panitia ');
INSERT INTO `alur_pendaftaran` (`id`, `nama`, `tanggal`, `keterangan`) VALUES (4, 'Login ke situs pendaftaran', '2021-03-01', 'Selanjutnya, akses halaman situs almanar.ponpes.id/psb/login-user dengan LOGIN menggunakan NISN dan Tanggal Lahir untuk melakukan pengisian data berupa:\r\n\r\n- Data diri\r\n\r\n- Data Orang Tua\r\n\r\n- Data Wali\r\n\r\n- Data Dokumen.\r\n\r\nNB: Jangan lupa menekan t');


#
# TABLE STRUCTURE FOR: app_information
#

DROP TABLE IF EXISTS `app_information`;

CREATE TABLE `app_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(250) NOT NULL,
  `instansi` varchar(250) NOT NULL,
  `tahun` int(11) NOT NULL,
  `logo` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `app_information` (`id`, `nama`, `instansi`, `tahun`, `logo`) VALUES (1, 'PPDB Online', 'SMK Muhammdiyah 2 Cepu', 2020, 'logo.png');


#
# TABLE STRUCTURE FOR: biaya
#

DROP TABLE IF EXISTS `biaya`;

CREATE TABLE `biaya` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `biaya` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `biaya` (`id`, `biaya`) VALUES (1, 15000);


#
# TABLE STRUCTURE FOR: biaya_pendidikan
#

DROP TABLE IF EXISTS `biaya_pendidikan`;

CREATE TABLE `biaya_pendidikan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `biaya` int(11) NOT NULL,
  `keterangan` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `biaya_pendidikan` (`id`, `biaya`, `keterangan`) VALUES (2, 150000, 'Biaya Pendaftaran');
INSERT INTO `biaya_pendidikan` (`id`, `biaya`, `keterangan`) VALUES (3, 1500000, 'Uang Gedung');


#
# TABLE STRUCTURE FOR: jadwal
#

DROP TABLE IF EXISTS `jadwal`;

CREATE TABLE `jadwal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jenjang` varchar(100) NOT NULL,
  `nama_tes` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `kuota` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=latin1;

INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (27, 'SDIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-13', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (28, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-03', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (29, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-04', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (30, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-05', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (31, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-06', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (32, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-03', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (33, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-04', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (34, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-05', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (35, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-06', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (36, 'TKIT', '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', '2021-02-07', 'Offline', 2);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (37, 'TKIT', '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', '2021-02-13', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (40, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-11', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (41, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-12', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (42, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-11', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (43, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-12', 'Online', 5);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (44, 'SMPIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-13', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (45, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-13', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (47, 'SMPIT Quran', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-27', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (48, 'TKIT A', '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', '2021-02-27', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (49, 'TKIT B', '1. Observasi Kepribadian<br>2. Interview Orangtua (TK)', '2021-02-27', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (50, 'SDIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-27', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (51, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-18', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (52, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-19', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (53, 'SMAIT', '-test akademik <br> -test baca iqro<br>test psikologi<br> -wawancara', '2021-03-01', 'Online', 1);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (54, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-24', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (55, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-25', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (56, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-26', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (57, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-02-26', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (58, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-03', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (59, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-04', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (60, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-05', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (61, 'SMPIT Akademik', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-06', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (62, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-03', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (63, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-04', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (64, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-05', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (65, 'SMAIT', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-06', 'Online', 10);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (66, 'SMPIT Quran', '1.	Test Akademik dan Al-Qur’an <br>2. Observasi Kepribadian<br>3. Interview Orangtua ', '2021-03-06', 'Offline', 20);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (67, 'TKIT A', 'TES AWAL', '2021-03-11', 'Online', 90);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (68, 'TKIT B', 'TES AWAL', '2021-03-11', 'Online', 90);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (69, '5', 'TES AWAL', '2021-03-31', 'Offline', 100);
INSERT INTO `jadwal` (`id`, `jenjang`, `nama_tes`, `tanggal`, `keterangan`, `kuota`) VALUES (70, '4', 'Tes Kecakapan', '2021-03-31', 'Offline', 100);


#
# TABLE STRUCTURE FOR: jadwal_pendaftaran
#

DROP TABLE IF EXISTS `jadwal_pendaftaran`;

CREATE TABLE `jadwal_pendaftaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal_mulai` date DEFAULT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `nama` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `jadwal_pendaftaran` (`id`, `tanggal_mulai`, `tanggal_selesai`, `nama`) VALUES (2, '2021-02-01', '2021-04-30', 'Pendaftaran Online');


#
# TABLE STRUCTURE FOR: jadwal_ujian
#

DROP TABLE IF EXISTS `jadwal_ujian`;

CREATE TABLE `jadwal_ujian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idunik` text NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jenjang
#

DROP TABLE IF EXISTS `jenjang`;

CREATE TABLE `jenjang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `keterangan` varchar(250) DEFAULT NULL,
  `logo` text DEFAULT NULL,
  `kuota` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `jenjang` (`id`, `nama`, `keterangan`, `logo`, `kuota`) VALUES (4, 'Teknik Kendaraan Ringan (Otomotif)', 'Mitra Industri TOYOTA Kudus (CV. Surya Indah Motor)', 'logo_Teknik_Kendaraan_Ringan_(Otomotif)_20210320105447.png', 100);
INSERT INTO `jenjang` (`id`, `nama`, `keterangan`, `logo`, `kuota`) VALUES (5, 'Teknik Instalasi Tenaga Listrik', 'Mitra Industri PT. B&D Transformer', 'logo_Teknik_Instalasi_Tenaga_Listrik_20210320105536.png', 1);
INSERT INTO `jenjang` (`id`, `nama`, `keterangan`, `logo`, `kuota`) VALUES (6, 'Teknik Bisnis & Sepeda Motor', 'Mitra Industri PT. Astra Honda Motor', 'logo_20210320105818.png', 100);
INSERT INTO `jenjang` (`id`, `nama`, `keterangan`, `logo`, `kuota`) VALUES (7, 'Asisten Keperawatan', 'Mitra RS PKU Muhammadiyah', 'logo_20210320105859.png', 100);


#
# TABLE STRUCTURE FOR: kelas
#

DROP TABLE IF EXISTS `kelas`;

CREATE TABLE `kelas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `jenjang_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `kelas_jenjang_id_IDX` (`jenjang_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `kelas` (`id`, `nama`, `jenjang_id`) VALUES (2, 'X A', 4);
INSERT INTO `kelas` (`id`, `nama`, `jenjang_id`) VALUES (3, 'X B', 4);
INSERT INTO `kelas` (`id`, `nama`, `jenjang_id`) VALUES (4, 'X C', 4);
INSERT INTO `kelas` (`id`, `nama`, `jenjang_id`) VALUES (5, 'X A', 5);


#
# TABLE STRUCTURE FOR: keringanan_biaya
#

DROP TABLE IF EXISTS `keringanan_biaya`;

CREATE TABLE `keringanan_biaya` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keterangan` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `keringanan_biaya` (`id`, `keterangan`) VALUES (2, 'Siswa berprestasi akademik peringkat 1.');
INSERT INTO `keringanan_biaya` (`id`, `keterangan`) VALUES (3, 'Siswa berprestasi non-akademik ( Juara tingkat kabupaten dna procinsi ).');
INSERT INTO `keringanan_biaya` (`id`, `keterangan`) VALUES (4, 'Siswa yang orang tuanya bekerja di Muhammadiyah.');


#
# TABLE STRUCTURE FOR: konfigurasi_sistem
#

DROP TABLE IF EXISTS `konfigurasi_sistem`;

CREATE TABLE `konfigurasi_sistem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_whatsapp` text NOT NULL,
  `api_ipaymu` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `email_host` varchar(300) NOT NULL,
  `email_port` varchar(300) NOT NULL,
  `email_user` varchar(300) NOT NULL,
  `email_pass` varchar(300) NOT NULL,
  `wa_lulus` text NOT NULL,
  `wa_tidak_lulus` text NOT NULL,
  `wa_cadangan` text NOT NULL,
  `wa_konfbayar_awal` text NOT NULL,
  `wa_konfbayar_akhir` text NOT NULL,
  `wa_suksesbayar` text NOT NULL,
  `nomor_daftar` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `konfigurasi_sistem` (`id`, `api_whatsapp`, `api_ipaymu`, `email`, `email_host`, `email_port`, `email_user`, `email_pass`, `wa_lulus`, `wa_tidak_lulus`, `wa_cadangan`, `wa_konfbayar_awal`, `wa_konfbayar_akhir`, `wa_suksesbayar`, `nomor_daftar`) VALUES (1, 'zqAQ1ofrvtOQQieu4SKnMcS1IeOv6sSXe69Tr02UGagiu1G2HFJcIOQWVfJw5gvD', '3EFF4444-7D58-440A-AC34-D8907A88A7E2', 'noreply@virtuinvite.com', 'mail.virtuinvite.com', '465', '', 'bismillah99', 'Assalamualaikum Selamat anda dinyatakan *', 'Mohon maaf anda dinyatakan Tidak lulus untuk melihat detail silahkan login pada link berikut ini https://ppdb.smkmuhammadiyah2cepu.sch.id/loginsantri', 'Mohon maaf anda dinyatakan sebagai Cadangan  untuk melihat detail silahkan login pada link berikut ini https://ppdb.smkmuhammadiyah2cepu.sch.id/loginsantri', 'Assalamualaikum, Anda sudah berhasil melakukan pendaftaran dengan data sebagai berikut', 'Silahkan melakukan pembayaran pada link yang sudah tertera untuk tahap selanjut nya', 'Pembayaran sudah berhasil silahkan login ke member area calon santri pada link https://ppdb.smkmuhammadiyah2cepu.sch.id/loginsantri . Info lebih lanjut hub pusat informasi PPDB : https://wa.me/6281283185454', 'PPDB');


#
# TABLE STRUCTURE FOR: kontak
#

DROP TABLE IF EXISTS `kontak`;

CREATE TABLE `kontak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `whatsapp` text NOT NULL,
  `kontak` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `facebook` text NOT NULL,
  `instagram` text NOT NULL,
  `twitter` text NOT NULL,
  `youtube` text NOT NULL,
  `alamat` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `kontak` (`id`, `whatsapp`, `kontak`, `email`, `facebook`, `instagram`, `twitter`, `youtube`, `alamat`) VALUES (1, '081380515414', 'tel:081380515414', 'Info@alfityanbogor.sch.id', '', '', '', '', 'Jl. Bengkel Roda Kampung Cipicung Desa Mekarsari Kecamatan Cileungsi Kabupaten Bogor Jawa Barat');


#
# TABLE STRUCTURE FOR: kontak_ppdb
#

DROP TABLE IF EXISTS `kontak_ppdb`;

CREATE TABLE `kontak_ppdb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `kontak` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `kontak_ppdb` (`id`, `nama`, `kontak`) VALUES (1, 'Nur Imamah', '0896-3056-2569');
INSERT INTO `kontak_ppdb` (`id`, `nama`, `kontak`) VALUES (3, 'Suharto', '0815-7543-0880');
INSERT INTO `kontak_ppdb` (`id`, `nama`, `kontak`) VALUES (4, 'Sulistyowati', '0813-2570-6953 ');


#
# TABLE STRUCTURE FOR: kontenhome
#

DROP TABLE IF EXISTS `kontenhome`;

CREATE TABLE `kontenhome` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flyer` varchar(100) NOT NULL,
  `video` text NOT NULL,
  `tentang` text NOT NULL,
  `tk` text NOT NULL,
  `sd` text NOT NULL,
  `smp` text NOT NULL,
  `sma` text NOT NULL,
  `link_panduan` text NOT NULL,
  `link_brosur` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `kontenhome` (`id`, `flyer`, `video`, `tentang`, `tk`, `sd`, `smp`, `sma`, `link_panduan`, `link_brosur`) VALUES (1, 'flyer.png', 'https://www.youtube.com/embed/E-L7vgAmVKg?feature=oembed&start&end&wmode=opaque&loop=0&controls=1&mute=0&rel=0&modestbranding=0', 'Al-Fityan Boarding School Bogor (ABSB) adalah cabang ke-6 dari Yayasan Al-Fityan. Hadir di tengah-tengah masyarakat dengan satu konsep pendidikan Islam yang memiliki program Islamic Character Building dan Tahfidz Al-Qur’an menuju terbentuknya generasi pemimpin yang cerdas dan bertaqwa. Dilengkapi fasilitas tenaga pendidik yang profesional, mari bergabung bersama kami. Mendidik dan membentuk putra-putri kita menjadi generasi Islam yang unggul dan bertaqwa.', 'TKIT Al Fityan School Bogor berdiri pada Juli 2017 dibawah naungan Yayasan Al Fityan Indonesia yang dipimpin oleh Syech Ali Sholah Al Zaitir selaku Direktur.', 'SDIT Al Fityan School Bogor berdiri pada Juli 2016 dibawah naungan Yayasan Al Fityan Indonesia yang dipimpin oleh Syech Ali Sholah Al Zaitir selaku Direktur.', 'SMPIT Al Fityan School Bogor berdiri pada Juli 2016 dibawah naungan Yayasan Al Fityan Indonesia yang dipimpin oleh Syech Ali Sholah Al Zaitir selaku Direktur.', 'SMAIT Al Fityan School Bogor berdiri pada Juli 2017 dibawah naungan Yayasan Al Fityan Indonesia yang dipimpin oleh Syech Ali Sholah Al Zaitir selaku Direktur.', '#', '#');


#
# TABLE STRUCTURE FOR: ppdb_call
#

DROP TABLE IF EXISTS `ppdb_call`;

CREATE TABLE `ppdb_call` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kontak` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `ppdb_call` (`id`, `kontak`) VALUES (1, '08173738393911343');
INSERT INTO `ppdb_call` (`id`, `kontak`) VALUES (2, '0899787979912131313');


#
# TABLE STRUCTURE FOR: setting_buka
#

DROP TABLE IF EXISTS `setting_buka`;

CREATE TABLE `setting_buka` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_buka` date DEFAULT NULL,
  `tgl_tutup` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `setting_buka` (`id`, `tgl_buka`, `tgl_tutup`) VALUES (1, '2021-03-21', '2021-04-30');


#
# TABLE STRUCTURE FOR: siswa
#

DROP TABLE IF EXISTS `siswa`;

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_uniq` text NOT NULL,
  `kode` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(100) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nisn` varchar(100) NOT NULL,
  `nik` varchar(100) NOT NULL,
  `no_kk` varchar(100) NOT NULL,
  `kode_pos` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `jenjang` varchar(100) NOT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `sekolah_asal` varchar(100) NOT NULL,
  `ukuran_seragam` varchar(100) NOT NULL,
  `riwayat_penyakit` varchar(100) NOT NULL,
  `hobi` varchar(150) NOT NULL,
  `foto` text NOT NULL,
  `punya_saudara` varchar(20) NOT NULL,
  `jenjang_saudara` varchar(20) NOT NULL,
  `nama_saudara` varchar(150) NOT NULL,
  `tinggi_badan` varchar(100) NOT NULL,
  `berat_badan` varchar(100) NOT NULL,
  `lingkar_kepala` varchar(100) NOT NULL,
  `anak_ke` int(11) NOT NULL,
  `jml_saudara` int(11) NOT NULL,
  `status_anak` varchar(100) NOT NULL,
  `jalur` varchar(100) DEFAULT NULL,
  `tahun_ajar` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `siswa_tahun_ajar_IDX` (`tahun_ajar`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=284 DEFAULT CHARSET=latin1;

INSERT INTO `siswa` (`id`, `id_uniq`, `kode`, `nama`, `jenis_kelamin`, `whatsapp`, `email`, `nisn`, `nik`, `no_kk`, `kode_pos`, `password`, `jenjang`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `sekolah_asal`, `ukuran_seragam`, `riwayat_penyakit`, `hobi`, `foto`, `punya_saudara`, `jenjang_saudara`, `nama_saudara`, `tinggi_badan`, `berat_badan`, `lingkar_kepala`, `anak_ke`, `jml_saudara`, `status_anak`, `jalur`, `tahun_ajar`) VALUES (280, 'babc11cc14514802f1d3e681cf0c2d0f', '5-2021030274', 'Eka Annas Solichin', 'Laki-Laki', '085729335052', 'annassolichin01@gmail.com', '123456', '3402072006780003', '3402072008030013', '56415', '25d55ad283aa400af464c76d713c07ad', '6', 'Sleman', '1994-06-30', 'Perum.PringAsri Jl ORI No 108 Gunungpring, Muntilan.', 'SMP N 3 Muntilan', '', '', 'TES', 'Eka_Annas_Solichin_20210321075156.jpg', '', '', '', '', '', '', 0, 0, '', 'Reguler', NULL);
INSERT INTO `siswa` (`id`, `id_uniq`, `kode`, `nama`, `jenis_kelamin`, `whatsapp`, `email`, `nisn`, `nik`, `no_kk`, `kode_pos`, `password`, `jenjang`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `sekolah_asal`, `ukuran_seragam`, `riwayat_penyakit`, `hobi`, `foto`, `punya_saudara`, `jenjang_saudara`, `nama_saudara`, `tinggi_badan`, `berat_badan`, `lingkar_kepala`, `anak_ke`, `jml_saudara`, `status_anak`, `jalur`, `tahun_ajar`) VALUES (281, '554f5960d3a1e1772f4f8b0fb0e6502b', '4-2021030281', 'Eka Annas Solichin', 'Laki-Laki', '082150716903', 'annassolichin@gmail.com', '7979678', '3402072006780003', '3402072008030013', '56415', '25d55ad283aa400af464c76d713c07ad', '4', 'Sleman', '1994-06-30', 'Perum Asri', 'SMP N 3 Muntilan', '', '', 'Membaca', '', '', '', '', '', '', '', 0, 0, '', '', NULL);
INSERT INTO `siswa` (`id`, `id_uniq`, `kode`, `nama`, `jenis_kelamin`, `whatsapp`, `email`, `nisn`, `nik`, `no_kk`, `kode_pos`, `password`, `jenjang`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `sekolah_asal`, `ukuran_seragam`, `riwayat_penyakit`, `hobi`, `foto`, `punya_saudara`, `jenjang_saudara`, `nama_saudara`, `tinggi_badan`, `berat_badan`, `lingkar_kepala`, `anak_ke`, `jml_saudara`, `status_anak`, `jalur`, `tahun_ajar`) VALUES (282, 'cca36c3dc33f27a9a07f3139b2ae2c10', '4-2021030282', 'Siswa 1', 'Laki-Laki', '085726674498', 'smkmudacepu@gmail.com', '123456', '335346678888', '64768875444777', '6555', '202cb962ac59075b964b07152d234b70', '4', 'BLORA', '1899-11-30', 'Hbvv  b', 'SMPN 2 CEPU', '', '', 'Bnvhn', 'Siswa_1_20210406091514.jpg', '', '', '', '', '', '', 0, 0, '', 'reguler', NULL);
INSERT INTO `siswa` (`id`, `id_uniq`, `kode`, `nama`, `jenis_kelamin`, `whatsapp`, `email`, `nisn`, `nik`, `no_kk`, `kode_pos`, `password`, `jenjang`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `sekolah_asal`, `ukuran_seragam`, `riwayat_penyakit`, `hobi`, `foto`, `punya_saudara`, `jenjang_saudara`, `nama_saudara`, `tinggi_badan`, `berat_badan`, `lingkar_kepala`, `anak_ke`, `jml_saudara`, `status_anak`, `jalur`, `tahun_ajar`) VALUES (283, '84d24cbb55ac7f7120f3943517e5c350', '4-2021040283', 'Siswa TKRO', 'Laki-laki', '081575430880', 'it.email009@gmail.com', '1234567', '', '', '', '202cb962ac59075b964b07152d234b70', '4', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, '', NULL, NULL);


#
# TABLE STRUCTURE FOR: siswa_bayar
#

DROP TABLE IF EXISTS `siswa_bayar`;

CREATE TABLE `siswa_bayar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `price` int(11) NOT NULL,
  `urlpayment` text NOT NULL,
  `trx_id` text NOT NULL,
  `sid` text NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_bayar` (`id`, `iduniq`, `tanggal`, `price`, `urlpayment`, `trx_id`, `sid`, `status`) VALUES (212, 'babc11cc14514802f1d3e681cf0c2d0f', '2021-03-21 05:49:34', 15000, 'https://my.ipaymu.com/payment/ACF21B28-B898-4446-97DD-2F40BD0484CF', '2961864', 'ACF21B28-B898-4446-97DD-2F40BD0484CF', 'berhasil');
INSERT INTO `siswa_bayar` (`id`, `iduniq`, `tanggal`, `price`, `urlpayment`, `trx_id`, `sid`, `status`) VALUES (213, '554f5960d3a1e1772f4f8b0fb0e6502b', '2021-03-28 08:04:10', 15000, 'https://my.ipaymu.com/payment/F2EAD708-C259-44A5-B853-B74906FB1BA6', '', 'F2EAD708-C259-44A5-B853-B74906FB1BA6', 'berhasil');
INSERT INTO `siswa_bayar` (`id`, `iduniq`, `tanggal`, `price`, `urlpayment`, `trx_id`, `sid`, `status`) VALUES (214, 'cca36c3dc33f27a9a07f3139b2ae2c10', '2021-03-30 03:59:08', 15000, 'https://my.ipaymu.com/payment/462F447A-5D62-442E-AEFE-79E3B8AEB884', '3022745', '462F447A-5D62-442E-AEFE-79E3B8AEB884', 'berhasil');
INSERT INTO `siswa_bayar` (`id`, `iduniq`, `tanggal`, `price`, `urlpayment`, `trx_id`, `sid`, `status`) VALUES (215, '84d24cbb55ac7f7120f3943517e5c350', '2021-04-03 02:16:01', 15000, 'https://my.ipaymu.com/payment/1C4152E9-1A26-4D33-A928-7B52E2A59FBC', '', '1C4152E9-1A26-4D33-A928-7B52E2A59FBC', '');


#
# TABLE STRUCTURE FOR: siswa_bayar_history
#

DROP TABLE IF EXISTS `siswa_bayar_history`;

CREATE TABLE `siswa_bayar_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trx_id` text NOT NULL,
  `sid` text NOT NULL,
  `status` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `user` varchar(100) NOT NULL,
  `siswa` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (178, '2961864', 'ACF21B28-B898-4446-97DD-2F40BD0484CF', 'pending', '2021-03-21 05:50:02', '', '');
INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (179, '', '', 'berhasil', '2021-03-21 06:54:45', '1', 'babc11cc14514802f1d3e681cf0c2d0f');
INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (180, '', '', 'berhasil', '2021-03-29 11:06:31', '1', '554f5960d3a1e1772f4f8b0fb0e6502b');
INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (181, '3022745', '462F447A-5D62-442E-AEFE-79E3B8AEB884', 'pending', '2021-03-30 04:02:04', '', '');
INSERT INTO `siswa_bayar_history` (`id`, `trx_id`, `sid`, `status`, `tanggal`, `user`, `siswa`) VALUES (182, '', '', 'berhasil', '2021-03-30 04:06:00', '1', 'cca36c3dc33f27a9a07f3139b2ae2c10');


#
# TABLE STRUCTURE FOR: siswa_dokumen
#

DROP TABLE IF EXISTS `siswa_dokumen`;

CREATE TABLE `siswa_dokumen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `type` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=380 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (364, 'babc11cc14514802f1d3e681cf0c2d0f', 'Kartu Keluarga', 'kartu_keluarga_123456.png');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (365, 'babc11cc14514802f1d3e681cf0c2d0f', 'Akta Kelahiran', 'akta_kelahiran_123456.png');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (368, 'babc11cc14514802f1d3e681cf0c2d0f', 'STTB', 'sttb_123456.pdf');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (369, '554f5960d3a1e1772f4f8b0fb0e6502b', 'Kartu Keluarga', 'kartu_keluarga_7979678.pdf');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (370, '554f5960d3a1e1772f4f8b0fb0e6502b', 'Akta Kelahiran', 'akta_kelahiran_7979678.pdf');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (371, '554f5960d3a1e1772f4f8b0fb0e6502b', 'STTB', 'sttb_7979678.pdf');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (375, 'babc11cc14514802f1d3e681cf0c2d0f', 'Tidak Mampu', 'tidak_mampu_123456.png');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (376, 'cca36c3dc33f27a9a07f3139b2ae2c10', 'Kartu Keluarga', 'kartu_keluarga_123456.jpg');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (377, 'cca36c3dc33f27a9a07f3139b2ae2c10', 'Akta Kelahiran', 'akta_kelahiran_123456.jpg');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (378, 'cca36c3dc33f27a9a07f3139b2ae2c10', 'STTB', 'sttb_123456.jpg');
INSERT INTO `siswa_dokumen` (`id`, `iduniq`, `type`, `file`) VALUES (379, 'cca36c3dc33f27a9a07f3139b2ae2c10', 'Tidak Mampu', 'tidak_mampu_123456.jpg');


#
# TABLE STRUCTURE FOR: siswa_kelas
#

DROP TABLE IF EXISTS `siswa_kelas`;

CREATE TABLE `siswa_kelas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kelas_id` varchar(100) DEFAULT NULL,
  `siswa_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `siswa_kelas_kelas_id_IDX` (`kelas_id`,`siswa_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_kelas` (`id`, `kelas_id`, `siswa_id`) VALUES (4, '3', '4-2021030281');
INSERT INTO `siswa_kelas` (`id`, `kelas_id`, `siswa_id`) VALUES (3, '3', '5-2021030274');


#
# TABLE STRUCTURE FOR: siswa_orangtua
#

DROP TABLE IF EXISTS `siswa_orangtua`;

CREATE TABLE `siswa_orangtua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `nama_ayah` varchar(200) NOT NULL,
  `pend_ayah` varchar(100) NOT NULL,
  `pekerjaan_ayah` varchar(200) NOT NULL,
  `pekerjaan_ayah_lain` text NOT NULL,
  `nik_ayah` varchar(200) NOT NULL,
  `tmp_lhr_ayah` varchar(200) NOT NULL,
  `tgl_lhr_ayah` date NOT NULL,
  `nomor_ayah` varchar(200) NOT NULL,
  `penghasilan_ayah` varchar(200) NOT NULL,
  `nama_ibu` varchar(200) NOT NULL,
  `pend_ibu` varchar(200) NOT NULL,
  `pekerjaan_ibu` varchar(200) NOT NULL,
  `pekerjaan_ibu_lain` text NOT NULL,
  `nik_ibu` varchar(200) NOT NULL,
  `tmp_lhr_ibu` varchar(200) NOT NULL,
  `tgl_lhr_ibu` date NOT NULL,
  `nomor_ibu` varchar(200) NOT NULL,
  `penghasilan_ibu` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_orangtua` (`id`, `iduniq`, `nama_ayah`, `pend_ayah`, `pekerjaan_ayah`, `pekerjaan_ayah_lain`, `nik_ayah`, `tmp_lhr_ayah`, `tgl_lhr_ayah`, `nomor_ayah`, `penghasilan_ayah`, `nama_ibu`, `pend_ibu`, `pekerjaan_ibu`, `pekerjaan_ibu_lain`, `nik_ibu`, `tmp_lhr_ibu`, `tgl_lhr_ibu`, `nomor_ibu`, `penghasilan_ibu`) VALUES (56, 'babc11cc14514802f1d3e681cf0c2d0f', 'Widjanarkoa', 'S2', 'Dokter', '', '33080830069400031', 'SlemanA', '2021-04-02', '08174641', '10000000', 'Hari Dwia', 'S2', 'Dokter', '', ' 34020704096100011', 'Sleman', '2021-03-19', '45654641', '10000000');
INSERT INTO `siswa_orangtua` (`id`, `iduniq`, `nama_ayah`, `pend_ayah`, `pekerjaan_ayah`, `pekerjaan_ayah_lain`, `nik_ayah`, `tmp_lhr_ayah`, `tgl_lhr_ayah`, `nomor_ayah`, `penghasilan_ayah`, `nama_ibu`, `pend_ibu`, `pekerjaan_ibu`, `pekerjaan_ibu_lain`, `nik_ibu`, `tmp_lhr_ibu`, `tgl_lhr_ibu`, `nomor_ibu`, `penghasilan_ibu`) VALUES (57, '554f5960d3a1e1772f4f8b0fb0e6502b', 'tes', 'SD', 'Lainnya', 'tes', '76765657', 'tes', '2021-03-31', '87576', '5000000', 'tess', 'SD', 'PNS', '', '798979878', 'tesssss', '2021-03-31', '789', '5000000');
INSERT INTO `siswa_orangtua` (`id`, `iduniq`, `nama_ayah`, `pend_ayah`, `pekerjaan_ayah`, `pekerjaan_ayah_lain`, `nik_ayah`, `tmp_lhr_ayah`, `tgl_lhr_ayah`, `nomor_ayah`, `penghasilan_ayah`, `nama_ibu`, `pend_ibu`, `pekerjaan_ibu`, `pekerjaan_ibu_lain`, `nik_ibu`, `tmp_lhr_ibu`, `tgl_lhr_ibu`, `nomor_ibu`, `penghasilan_ibu`) VALUES (58, 'cca36c3dc33f27a9a07f3139b2ae2c10', 'Alm. ROBERT HUTTING', 'S1', 'Tentara', '', '6453454354333', 'Bnvhhh', '2021-04-01', '085555544', '5000000', 'ARUM KURNIASIH', 'D3', 'Guru', '', '65434677575765', 'Bkhhhgg', '2021-04-01', '0865444566666', '5000000');


#
# TABLE STRUCTURE FOR: siswa_otp
#

DROP TABLE IF EXISTS `siswa_otp`;

CREATE TABLE `siswa_otp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `otp` varchar(100) DEFAULT NULL,
  `nomor` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (1, '485176', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (2, '967081', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (3, '852160', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (4, '074726', '082150716903', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (5, '341948', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (6, '616523', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (7, '715537', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (8, '699643', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (9, '256674', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (10, '514235', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (11, '865677', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (12, '893500', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (13, '133510', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (14, '704466', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (15, '856264', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (16, '854031', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (17, '589178', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (18, '105705', '085729335052', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (19, '846763', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (20, '490097', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (21, '985366', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (22, '169694', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (23, '702804', '0857293350521', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (24, '351159', '0878812313', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (25, '595842', '085729335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (26, '065068', '085726674498', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (27, '159086', '081231534620', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (28, '613134', '081231534620', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (29, '634898', '081231534620', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (30, '555586', '0857129335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (31, '350223', '0857129335052', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (32, '418294', '082150716903', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (33, '156607', '085726674498', '0');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (34, '046595', '085726674498', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (35, '368641', '082314936353', '1');
INSERT INTO `siswa_otp` (`id`, `otp`, `nomor`, `status`) VALUES (36, '827985', '081575430880', '1');


#
# TABLE STRUCTURE FOR: siswa_pengumuman
#

DROP TABLE IF EXISTS `siswa_pengumuman`;

CREATE TABLE `siswa_pengumuman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `nilai` int(11) NOT NULL,
  `status` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_pengumuman` (`id`, `iduniq`, `nilai`, `status`) VALUES (21, 'babc11cc14514802f1d3e681cf0c2d0f', 0, 'Lulus');
INSERT INTO `siswa_pengumuman` (`id`, `iduniq`, `nilai`, `status`) VALUES (22, '554f5960d3a1e1772f4f8b0fb0e6502b', 0, 'Lulus');
INSERT INTO `siswa_pengumuman` (`id`, `iduniq`, `nilai`, `status`) VALUES (23, 'cca36c3dc33f27a9a07f3139b2ae2c10', 0, 'Lulus');


#
# TABLE STRUCTURE FOR: siswa_prestasi
#

DROP TABLE IF EXISTS `siswa_prestasi`;

CREATE TABLE `siswa_prestasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `prestasi` varchar(500) NOT NULL,
  `file` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_prestasi` (`id`, `iduniq`, `prestasi`, `file`) VALUES (76, 'babc11cc14514802f1d3e681cf0c2d0f', 'asdasdasd', 'Prestasi_asdasdasd_20210322084957.png');


#
# TABLE STRUCTURE FOR: siswa_ujian
#

DROP TABLE IF EXISTS `siswa_ujian`;

CREATE TABLE `siswa_ujian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduniq` text NOT NULL,
  `idjadwal` text NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=latin1;

INSERT INTO `siswa_ujian` (`id`, `iduniq`, `idjadwal`, `tanggal`) VALUES (180, 'babc11cc14514802f1d3e681cf0c2d0f', '69', '0000-00-00');
INSERT INTO `siswa_ujian` (`id`, `iduniq`, `idjadwal`, `tanggal`) VALUES (181, '554f5960d3a1e1772f4f8b0fb0e6502b', '70', '0000-00-00');
INSERT INTO `siswa_ujian` (`id`, `iduniq`, `idjadwal`, `tanggal`) VALUES (182, 'cca36c3dc33f27a9a07f3139b2ae2c10', '70', '0000-00-00');


#
# TABLE STRUCTURE FOR: syarat_administrasi
#

DROP TABLE IF EXISTS `syarat_administrasi`;

CREATE TABLE `syarat_administrasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (2, 'Menyerahkan foto copy STTB SMP / MTs sederajat, (bisa menyusul) atau membawa kartu peserta Ujian Nasional (UN)');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (3, 'Menyerahkan pas foto ukuran 3 x 4 (2 lembar)');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (4, 'Foto copy Kartu Keluarga (KK)');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (5, 'Foto copy AKTE kelahiran');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (6, 'Usia maksimal 21 tahun');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (7, 'Tidak bertato / bertindik');
INSERT INTO `syarat_administrasi` (`id`, `nama`) VALUES (8, 'Tidak pernah tersangkut tindakan pidana');


#
# TABLE STRUCTURE FOR: tahun_akademik
#

DROP TABLE IF EXISTS `tahun_akademik`;

CREATE TABLE `tahun_akademik` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tahun` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tahun_akademik` (`id`, `tahun`, `status`) VALUES (2, '2021/2022', 'Aktif');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_uniq` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `username` varchar(100) NOT NULL,
  `foto` text NOT NULL,
  `level` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `user` (`id`, `id_uniq`, `email`, `password`, `username`, `foto`, `level`) VALUES (1, 'c4ca4238a0b923820dcc509a6f75849b', 'adminsistem@gmail.com', '25d55ad283aa400af464c76d713c07ad', 'Administrator', 'Administrator_20210320111533.png', 'Administrator');


#
# TABLE STRUCTURE FOR: v_jadwal
#

DROP TABLE IF EXISTS `v_jadwal`;

CREATE ALGORITHM=MERGE DEFINER=`smkmuha2_ppdb`@`%` SQL SECURITY DEFINER VIEW `v_jadwal` AS select `b`.`kode` AS `kode`,`b`.`jenis_kelamin` AS `jenis_kelamin`,`b`.`whatsapp` AS `whatsapp`,`b`.`jenjang` AS `jenjang`,`a`.`iduniq` AS `iduniq`,`b`.`id` AS `id`,`a`.`sid` AS `sid`,`a`.`trx_id` AS `trx_id`,date_format(`a`.`tanggal`,'%d/%m/%Y %h:%i') AS `tanggal`,`a`.`price` AS `price`,`b`.`nama` AS `nama`,`b`.`email` AS `email`,`a`.`status` AS `status`,date_format(`c`.`tanggal`,'%d/%m/%Y') AS `tanggal_ujian` from ((`siswa_bayar` `a` join `siswa` `b` on(`b`.`id_uniq` = `a`.`iduniq`)) left join `siswa_ujian` `c` on(`c`.`iduniq` = `a`.`iduniq`));

utf8mb4_general_ci;

INSERT INTO `v_jadwal` (`kode`, `jenis_kelamin`, `whatsapp`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `tanggal_ujian`) VALUES ('5-2021030274', 'Laki-Laki', '085729335052', '6', 'babc11cc14514802f1d3e681cf0c2d0f', 280, 'ACF21B28-B898-4446-97DD-2F40BD0484CF', '2961864', '21/03/2021 05:49', 15000, 'Eka Annas Solichin', 'annassolichin01@gmail.com', 'berhasil', '00/00/0000');
INSERT INTO `v_jadwal` (`kode`, `jenis_kelamin`, `whatsapp`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `tanggal_ujian`) VALUES ('4-2021030281', 'Laki-Laki', '082150716903', '4', '554f5960d3a1e1772f4f8b0fb0e6502b', 281, 'F2EAD708-C259-44A5-B853-B74906FB1BA6', '', '28/03/2021 08:04', 15000, 'Eka Annas Solichin', 'annassolichin@gmail.com', 'berhasil', '00/00/0000');
INSERT INTO `v_jadwal` (`kode`, `jenis_kelamin`, `whatsapp`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `tanggal_ujian`) VALUES ('4-2021030282', 'Laki-Laki', '085726674498', '4', 'cca36c3dc33f27a9a07f3139b2ae2c10', 282, '462F447A-5D62-442E-AEFE-79E3B8AEB884', '3022745', '30/03/2021 03:59', 15000, 'Siswa 1', 'smkmudacepu@gmail.com', 'berhasil', '00/00/0000');
INSERT INTO `v_jadwal` (`kode`, `jenis_kelamin`, `whatsapp`, `jenjang`, `iduniq`, `id`, `sid`, `trx_id`, `tanggal`, `price`, `nama`, `email`, `status`, `tanggal_ujian`) VALUES ('4-2021040283', 'Laki-laki', '081575430880', '4', '84d24cbb55ac7f7120f3943517e5c350', 283, '1C4152E9-1A26-4D33-A928-7B52E2A59FBC', '', '03/04/2021 02:16', 15000, 'Siswa TKRO', 'it.email009@gmail.com', '', NULL);


